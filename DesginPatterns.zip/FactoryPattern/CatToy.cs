﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern
{
    public class CatToy : IPetToy
    {
        private string catToyName = string.Empty;
        private bool isMakeSound;

        public string ToyName
        {
            get { return this.catToyName; }
            set { this.catToyName = value; }
        }

        public bool IsMakeSound
        {
            get { return this.isMakeSound; }
            set { this.isMakeSound = value; }
        }


        public string PlaySound()
        {
            return this.isMakeSound ? "Irratating Sound" : "This toy does NOT make sounds";
        }
    }
}
