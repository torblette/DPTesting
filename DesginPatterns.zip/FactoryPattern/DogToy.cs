﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryPattern
{
    public class DogToy : IPetToy
    {
        private string dogToyName = string.Empty;
        private bool isMakeSound;

        public string ToyName
        {
            get { return this.dogToyName; }
            set { this.dogToyName = value;  }
        }

        public bool IsMakeSound
        {
            get { return this.isMakeSound; }
            set { this.isMakeSound = value; }
        }
        
        public string PlaySound()
        {
            return this.isMakeSound ? "Barking Sound" : "This toy does NOT make sounds";
        }
    }

    
}
