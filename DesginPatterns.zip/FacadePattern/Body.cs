﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacadePattern
{
    class Body
    {
        // Body would include electrical, interior, and other subsystems
        private string bodytype;
        private bool isvalidbody;

        private string BodyType
        {
            get { return this.bodytype; }
            set { this.bodytype = value; }
        }

        public bool IsValidBody
        {
            get { return this.isvalidbody; }
            set { this.isvalidbody = value; }
        }


        public void CreateBody(string bodystyle)
        {
            this.isvalidbody = false;
            this.bodytype = bodystyle;

            if (this.bodytype.ToUpper() == "COUPE" ||
                this.bodytype.ToUpper() == "SEDAN" ||
                this.bodytype.ToUpper() == "PICKUP") this.isvalidbody = true;
        }
    }
}
