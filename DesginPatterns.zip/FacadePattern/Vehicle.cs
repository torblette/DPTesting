﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacadePattern
{
    public class Vehicle
    {
        // Light-weight demonstration of facade pattern

        private Body newbody = new Body();
        private Engine newengine = new Engine();

        public bool CreateVehicle(int numcylinders, string enginetype, string bodytype)
        {
            newengine.CreateEngine(numcylinders, enginetype);

            newbody.CreateBody(bodytype);
            
            return (newengine.IsValidEngine == newbody.IsValidBody);
        }
    }
}
