﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FacadePattern
{
    

    class Engine
    {
        // Would include other drive train subsystems

        private EngineTypeEnum enginetype;
        private int numberofcylinders = 0;
        private bool isvalidengine = false;

        private enum EngineTypeEnum
        {
            Gasoline = 0,
            Diesel = 1
        }

        // Enumeration of possible number of cylinders in an engine
        private enum CylindersEnum
        {
            Three = 3,
            Four = 4,
            Six = 6,
            Eight = 8,
            Ten = 10,
            Twelve = 12
        }

        // Arrays for valid number of cylinders by engine type
        private List<CylindersEnum> gasenginecylinders;
        private List<CylindersEnum> dieselenginecylinders;

        // These are private and not exposed now, but could be used in the Vehicle class
        private List<CylindersEnum> GasEngineCylinders
        {
            get { return this.gasenginecylinders; }
            set { this.gasenginecylinders = value; }
        }

        private List<CylindersEnum> DieselEngineCylinders
        {
            get { return this.dieselenginecylinders; }
            set { this.dieselenginecylinders = value; }
        }

        private int NumberOfCylinders
        {
            get { return this.numberofcylinders; }
            set { this.numberofcylinders = value; }
        }

        private EngineTypeEnum EngineType
        {
            get { return this.enginetype; }
            set { this.enginetype = value; }
        }

        public bool IsValidEngine
        {
            get { return this.isvalidengine; }
            set { this.isvalidengine = value; }
        }



        public Engine()
        {
            this.gasenginecylinders = new List<CylindersEnum>
            {
                CylindersEnum.Four,
                CylindersEnum.Six,
                CylindersEnum.Eight,
                CylindersEnum.Ten,
                CylindersEnum.Twelve
            };

            this.dieselenginecylinders = new List<CylindersEnum>
            {
                CylindersEnum.Three,
                CylindersEnum.Eight,
                CylindersEnum.Ten
            };
        }



        public void CreateEngine(int numcylinders, string enginetype)
        {
            this.numberofcylinders = numcylinders;

            if (enginetype.ToUpper() == "GASOLINE")
            {
                EngineType = EngineTypeEnum.Gasoline;
                this.isvalidengine = IsValidGasolineEngine() ? true : false;
            }
            else if (enginetype.ToUpper() == "DIESEL")
            {
                EngineType = EngineTypeEnum.Diesel;
                this.isvalidengine = IsValidDieselEngine() ? true : false;
            }
            
        }


        private bool IsValidGasolineEngine()
        {
            // Could use this to pre-verify it is a valid number of cylinders before checking the enging
            //Enum.IsDefined(typeof(CylindersEnum), this.numberofcylinders);

            return this.gasenginecylinders.Contains((CylindersEnum)this.numberofcylinders); 
        }

        private bool IsValidDieselEngine()
        {
            return this.dieselenginecylinders.Contains((CylindersEnum)this.numberofcylinders);
        }

    }
}
