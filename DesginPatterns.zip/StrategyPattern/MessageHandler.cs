﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    public class MessageHandler : IMessageHandler
    {
        // Pointer to CreateMessage method 
        private delegate string MessageString(string sPrefix, string sExMsg);

        private event MessageString ExceptionEvent;
        private event MessageString ErrorEvent;
        private event MessageString WarningEvent;
        private event MessageString InformationEvent;
        
        private bool ishandled = false;

        const string InfoPrefix = "INFORMATION";
        const string WarnPrefix = "WARNING";
        const string ErrPrefix = "ERROR";
        const string ExPrefix = "EXCEPTION";
        

        public bool IsMessageHandled
        {
            get { return this.ishandled; }
            set { this.ishandled = value; }
        }
        

        public void DisplayMessage()
        {
            throw new NotImplementedException();
        }

        public void WriteLogMessage(MessageTypeEnum messagetypeenum, string sMessage)
        {
            try
            {
                // Multi-cast delegate uses the "+=" overloaded operator. Its not needed here, but used since enhancements needed for message handling
                switch ((int)messagetypeenum)
                {
                    case (int)MessageTypeEnum.Information:
                        this.InformationEvent += new MessageString(this.CreateMessage);
                        Console.WriteLine(this.InformationEvent(InfoPrefix, sMessage));
                        this.ishandled = true;
                        break;
                    case (int)MessageTypeEnum.Warning:
                        this.WarningEvent += new MessageString(this.CreateMessage);
                        Console.WriteLine(this.WarningEvent(ExPrefix, sMessage));
                        this.ishandled = true;
                        break;
                    case (int)MessageTypeEnum.Error:
                        this.ErrorEvent += new MessageString(this.CreateMessage);
                        Console.WriteLine(this.ErrorEvent(ExPrefix, sMessage));
                        this.ishandled = true;
                        break;
                    case (int)MessageTypeEnum.Exception:
                        this.ExceptionEvent += new MessageString(this.CreateMessage);
                        Console.WriteLine(this.ExceptionEvent(ExPrefix, sMessage));
                        this.ishandled = true;
                        break;
                }
            }
            catch (Exception ex)
            {
                this.ExceptionEvent += new MessageString(this.CreateMessage);
                Console.WriteLine(this.ExceptionEvent(ExPrefix, ex.Message));
                this.ishandled = false;
            }

            
        }

        public void SendAlertMessage()
        {
            throw new NotImplementedException();
        }
        
        private string CreateMessage(string sPrefix, string sMessage)
        {
            return string.Format("{0}: {1}", sPrefix, sMessage);
        }

        private void WriteMessageToLog(string sMessage)
        {
            // need a class/assempbly for logs - or use an open source package?
            //  delete older log files - config parmaeter
            //  verify directory of logs - config parameter
            //  check that a log file exists, if not create
            //  append messages to log
        }
    }
}
