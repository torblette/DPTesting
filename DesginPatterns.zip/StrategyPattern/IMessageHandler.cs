﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StrategyPattern
{
    public enum MessageTypeEnum
    {
        Information = 0,
        Warning = 1,
        Error = 2,
        Exception = 3
    }

    public interface IMessageHandler
    {
        //string Message { get; set; }

        bool IsMessageHandled { get; set; }

        //void SetMessageType(MessageTypeEnum value);

        void DisplayMessage();

        void WriteLogMessage(MessageTypeEnum MsgType, string Message);

        void SendAlertMessage();
    }
}
