﻿
A console application to demonstrate a few patterns, written with VisualStudio 2015


=======================
Factory Pattern Example
=======================

A quick example of the Factory Pattern created as part of a recent interview request


========================
Strategy Pattern Example
========================

This is an example of message handling using delegates.  This is a first pass at figuring out a new way to do some messaging, alerting, and logging. 
There are plenty of 3rd party add on packages to handle this, but it’s nice to have control of your own internal messaging, alerting and logging.  

Eventually, I would like to add a standardized JSON messaging pattern that can be serialized and passed to an endpoint to be handled in any way deemed appropriate.


======================
Facade Pattern Example
======================

An example of creating a front for creating something.  In this case, creating a vehicle with an engine and body. It’s obvious that there is much more to creating a vehicle, 
but this demonstrates the use of the pattern to only expose the vehicle class and all other classes used to create a vehicle are hidden


======
Extras
======

During a recent interview I was asked to find the number of squares in a square grid. We wrote the algorithm on a white board and discussed the pattern. 
Thought it would be good to put it into code.
