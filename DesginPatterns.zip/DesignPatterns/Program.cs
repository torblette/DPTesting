﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using FacadePattern;
using FactoryPattern;
using StrategyPattern;
using Newtonsoft.Json;

namespace DesignPatterns
{
    public static class Program
    {
        private static string execuctiontime;
        private static DateTime starttime, endtime;
        private static TimeSpan timeDiff;

        public enum PetToyType
        {
            DogToy = 0,
            CatToy = 1,
            Other = 99
        }

        public static string ExecuctionTime
        {
            get { return execuctiontime; }
            set { execuctiontime = value; }
        }
        
        static void Main(string[] args)
        {
            #region PetToyShop - Factory Pattern example
            Console.WriteLine(string.Format("  "));
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine("Factory Pattern - Pet Toy Store");

            // Pet Toy Interface
            // Get input for Dog or Cat Toy
            starttime = DateTime.Now;

            IPetToy objPetToy = null;

            // This value would normally be inputs as the pet toy is built
            int intToyType = (int)PetToyType.DogToy;

            switch (intToyType)
            {
                case ((int)PetToyType.DogToy):
                    objPetToy = new DogToy();
                    break;
                case ((int)PetToyType.CatToy):
                    objPetToy = new CatToy();
                    break;
                case ((int)PetToyType.Other):
                    objPetToy = null;
                    break;
                default:
                    break;
            }

            if (objPetToy != null)
            {
                // These values would normally be inputs as the pet toy is built
                objPetToy.ToyName = "TestToyName";
                objPetToy.IsMakeSound = true;

                Console.WriteLine(string.Format("The toy [{0}] is a [{1}] and makes the [{2}].", objPetToy.ToyName, objPetToy.GetType(), objPetToy.PlaySound()));
            }

            endtime = DateTime.Now;
            GetExecutionTime();
            Console.WriteLine(string.Format("Execution Time [{0} ms]", ExecuctionTime));
            #endregion


            #region Messaging - Stategy Pattern
            Console.WriteLine(string.Format("  "));
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine("Stategy Pattern - Messaging");

            starttime = DateTime.Now;

            // Create a message object then use to write message to a log throughout a process
            // 10ms
            MessageHandler msObj = new MessageHandler();
            msObj.WriteLogMessage(MessageTypeEnum.Information, "Testing");
            Console.WriteLine(string.Format("IsMessageHandled [{0}]", msObj.IsMessageHandled));

            endtime = DateTime.Now;

            GetExecutionTime();
            Console.WriteLine(string.Format("  "));
            Console.WriteLine(string.Format("Execution Time [{0} ms]", ExecuctionTime));
            #endregion



            #region - Facade Pattern
            Console.WriteLine("  ");
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine("Facade Pattern - Creating a new vehicle");

            starttime = DateTime.Now;

            Vehicle MyNewRide = new Vehicle();
            int iCylinders = 8;
            string sEngineType = "diesel";
            string sBodyType = "coupe";
            Console.WriteLine(string.Format("My new ride was successfully created [{0}] - A {1} cylinder, {2} engine with a {3} styled body.", MyNewRide.CreateVehicle(iCylinders, sEngineType, sBodyType), iCylinders, sEngineType, sBodyType));

            endtime = DateTime.Now;

            GetExecutionTime();
            Console.WriteLine(string.Format("  "));
            Console.WriteLine(string.Format("Execution Time [{0} ms]", ExecuctionTime));
            #endregion


            #region - Extras
            // During a recent interview I was asked this question and we wrote the algorithm on a white board. Thought it would be good to put it into code
            Console.WriteLine("  ");
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine(string.Format("**********************************"));
            Console.WriteLine("Calculating Squares in a Grid");
            int iGridSize = 4;
            Console.WriteLine(string.Format("Number Of Squares in a {0}X{0} Grid is {1}", iGridSize, CountingSquares.CalculateSquares(iGridSize)));
            #endregion

            Console.ReadKey();
        }


        private static void GetExecutionTime()
        {
            timeDiff = endtime - starttime;
            execuctiontime = timeDiff.TotalMilliseconds.ToString();
        }
    }

    public static class CountingSquares
    {
        // Calculate the number of squares in a grid of NxN squares
        //  Squares can overlap
        //  Example
        //    //1x1 has 1 = 1 square
        //    //2x2 has 1 + 4 = 5 squares
        //    //3x3 has 1 + 4 + 9 = 14 squares
        //    //4x4 has 1 + 4 + 9 + 16 = 30 squares
        //    //5x5 has 1 + 4 + 9 + 16 + 25 = 55 squares

        public static int CalculateSquares(int GridSize)
        {
            int iTotalSquares = 0;

            for (int iNum = 1; iNum <= GridSize; iNum++)
            {
                iTotalSquares += Convert.ToInt32(Math.Pow(iNum, 2));
            }
            //Console.WriteLine(string.Format("NumberOfSquares in a {0}X{0} Grid is {1}", iNumSq, iTtlSq));

            return iTotalSquares;
        }
    }

}
